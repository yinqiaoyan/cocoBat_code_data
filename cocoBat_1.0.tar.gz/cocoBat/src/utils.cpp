#include <RcppArmadillo.h>
#include <RcppDist.h>
#include <stdio.h>
#include <roptim.h>
#include <cmath>
#include <random>
#include <RcppArmadilloExtensions/sample.h>
// [[Rcpp::depends(RcppArmadillo, RcppDist, roptim)]]
// [[Rcpp::plugins(openmp)]]
using namespace arma;
using namespace Rcpp;
using namespace std;
using namespace roptim;

#ifdef _OPENMP
#include <omp.h>
#endif


// // [[Rcpp::export]]
// arma::mat Lambda_func_rcpp(arma::mat dist_val, double eta2_val) {
//   return(exp( -dist_val / (2 * eta2_val) ));
// }



// [[Rcpp::export]]
arma::rowvec colMeans_rcpp(Rcpp::NumericMatrix mat) {

  arma::mat mat_arma = as<arma::mat>(mat);
  return arma::mean( mat_arma, 0 );
}



// Build cloud semivariances for a single vector z (length n) in the same
// lower-tri order as lower_tri_indices (i>j)
inline arma::vec semivar_cloud_from_z(const arma::vec& z) {
  int n = z.n_elem;
  arma::vec sv(n * (n - 1) / 2);
  arma::uword k = 0;
  for (int j = 0; j < n; ++j) {
    for (int i = j + 1; i < n; ++i) {
      double diff = z(i) - z(j);
      sv(k++) = 0.5 * diff * diff;
    }
  }
  return sv;
}


// -------- objective for optim (equal-weight SSE) --------
// par: length-2 numeric (delta2, eta)
// sv_tri: vector of semivariances for all i<j (lower-tri)
// dists_tri: vector of distances for all i<j (lower-tri)
// eps: small positive for guarding
static double obj_cloud_wls_equal_cpp(const arma::vec& par,
                                     const arma::vec& sv_tri,
                                     const arma::vec& dists_tri,
                                     const double eps) {
  double delta2 = par(0);
  double eta    = par(1);

  if (!std::isfinite(delta2) || !std::isfinite(eta) || delta2 <= eps || eta <= eps) {
    return 1e100;
  }

  // pred = delta2 * (1 - exp(-d/(2*eta)))
  arma::vec pred = delta2 * (1.0 - arma::exp(-dists_tri / (2.0 * eta)));
  arma::vec res  = sv_tri - pred;
  double sse = arma::dot(res, res);
  if (!std::isfinite(sse)) return 1e100;
  return sse;
}


// This wrapper is what R's optim will call.
// IMPORTANT: signature must accept SEXP and return SEXP/double.
SEXP obj_cloud_wls_equal_wrap(SEXP parSEXP,
                              SEXP svSEXP,
                              SEXP dSEXP,
                              SEXP epsSEXP) {
  arma::vec par      = Rcpp::as<arma::vec>(parSEXP);
  arma::vec sv_tri   = Rcpp::as<arma::vec>(svSEXP);
  arma::vec dists_tri= Rcpp::as<arma::vec>(dSEXP);
  double eps         = Rcpp::as<double>(epsSEXP);

  double out = obj_cloud_wls_equal_cpp(par, sv_tri, dists_tri, eps);
  return Rcpp::wrap(out);
}



// ---- const ----
const double INV_SQRT_2PI = 0.39894228040143267794; // 1/sqrt(2*pi)

// ---- standard normal pdf and cdf ----
inline double norm_pdf(double x) {
  return INV_SQRT_2PI * std::exp(-0.5 * x * x);
}

inline double norm_cdf(double x) {
  // f(x) = 0.5 * erfc(-x / sqrt(2))
  return 0.5 * std::erfc(-x / std::sqrt(2.0));
}

// ---- log-density of Inv-Gamma(shape, scale) ----
inline double log_dinvgamma(double x, double shape, double scale) {
  if (x <= 0.0) return -INFINITY;
  return shape * std::log(scale) - std::lgamma(shape)
    - (shape + 1.0) * std::log(x) - scale / x;
}

// ---- log-density of truncated normal N(mean, sd^2) on [0,+infty) ----
inline double log_dtruncnorm_0inf(double x, double mean, double sd) {
  if (x <= 0.0) return -INFINITY;
  double alpha = (0.0 - mean) / sd;
  double Z = 1.0 - norm_cdf(alpha);     // normalizing constant
  double z = (x - mean) / sd;
  double logphi = std::log(norm_pdf(z));
  return logphi - std::log(sd) - std::log(Z);
}

// ---- Sample from a truncated normal N(mean, sd^2) on [0,+infty) ----
template <class URNG>
double rtruncnorm_0inf(double mean, double sd, URNG &rng) {
  std::normal_distribution<double> norm(mean, sd);
  double x;
  do {
    x = norm(rng);
  } while (x <= 0.0);
  return x;
}

// ---- Construct Lambda(dists, eta) ----
inline arma::mat make_Lambda(const arma::mat &dists, double eta) {
  arma::mat Lambda = dists;
  double denom = 2.0 * eta;
  Lambda /= denom;
  Lambda *= -1.0;
  Lambda = arma::exp(Lambda);
  return Lambda;
}

// Given the Cholesky factor L of Lambda and delta2, compute
// log N(z; mu, Sigma), where Sigma = delta2 * Lambda and z_centered = z - mu.
inline double log_mvn_from_Lambda_delta(const arma::vec &z_centered,
                                        const arma::mat &L_Lambda,
                                        double delta2) {
  int n = z_centered.n_elem;

  // compute Lambda^{-1} z_centered
  arma::vec y = arma::solve(arma::trimatl(L_Lambda), z_centered);
  arma::vec v = arma::solve(arma::trimatu(L_Lambda.t()), y);
  double quad_Lambda = arma::dot(z_centered, v); // (z-mu)' Lambda^{-1} (z-mu)

  // log|Lambda| = 2 * sum(log(diag(L)))
  double log_det_Lambda = 2.0 * arma::sum(arma::log(L_Lambda.diag()));

  // Sigma = delta2 * Lambda
  double log_det_Sigma = n * std::log(delta2) + log_det_Lambda;
  double quad_Sigma    = quad_Lambda / delta2;

  double val = -0.5 * (n * std::log(2.0 * M_PI) + log_det_Sigma + quad_Sigma);
  return val;
}


// -----------------------------------------------------------------------------
//   Run MCMC for all genes jointly, using OpenMP to parallelize over the
//   gene dimension.
// -----------------------------------------------------------------------------
//
// Returns a list with:
//   $gamma_post  : G × B × num_iters (array)
//   $delta2_post : G × B × num_iters (array)
//   $eta_post    : G × B × num_iters (array)
// -----------------------------------------------------------------------------

// [[Rcpp::export]]
Rcpp::List mcmc_all_genes_cpp(
    int G,
    int B,
    int num_iters,
    Rcpp::List Z_mat,         // len: p，each element: G × n_i
    Rcpp::List dists_list,    // len: p，each element: n_i × n_i
    arma::vec num_samples,    // len: B
    arma::mat gamma_init,     // G × B
    arma::mat delta2_init,    // G × B
    arma::mat eta_init,       // G × B
    arma::vec kappa_b,        // len: B-1
    arma::vec tau2_b,         // len: B-1
    arma::vec lambda_delta_b, // len: B
    arma::vec theta_delta_b,  // len: B
    arma::vec lambda_eta_b,   // len: B
    arma::vec theta_eta_b,    // len: B
    int base_seed = 1,        // random seed
    int n_threads = 0         // number of threads in omp
) {
  // Z_mat / dists_list -> Armadillo
  std::vector<arma::mat> Z_list(B);
  std::vector<arma::mat> D_list(B);
  for (int i = 0; i < B; ++i) {
    Z_list[i] = Rcpp::as<arma::mat>(Z_mat[i]);      // G × n_i
    D_list[i] = Rcpp::as<arma::mat>(dists_list[i]); // n_i × n_i
  }

  // save MCMC：G × B × num_iters
  arma::cube gamma_post(G, B, num_iters, arma::fill::zeros);
  arma::cube delta2_post(G, B, num_iters, arma::fill::zeros);
  arma::cube eta_post(G, B, num_iters, arma::fill::zeros);

  // ------------------------- OpenMP -------------------------
#ifdef _OPENMP
  int max_threads = omp_get_max_threads();

  // Leave 1 thread for the main thread if possible
  int usable_threads = std::max(1, max_threads - 1);

  if (n_threads <= 0) {
    n_threads = usable_threads;
  } else {
    n_threads = std::min(n_threads, usable_threads);
  }

  Rcpp::Rcout << "OpenMP is available. "
              << "max_threads = " << max_threads
              << ", requested = " << n_threads << std::endl;

  omp_set_dynamic(0);
  omp_set_num_threads(n_threads);

  int effective_threads = omp_get_max_threads();
  Rcpp::Rcout << "Using "
              << effective_threads << " thread(s) for MCMC."
              << std::endl;

#pragma omp parallel
{
  int tid = omp_get_thread_num();
  std::mt19937 rng(base_seed + tid * 10007);
  std::uniform_real_distribution<double> unif01(0.0, 1.0);

#pragma omp for schedule(static)
  for (int g = 0; g < G; ++g) {
#else
{
  Rcpp::Rcout << "OpenMP is NOT available. "
              << "Running single-threaded." << std::endl;
  std::mt19937 rng(base_seed);
  std::uniform_real_distribution<double> unif01(0.0, 1.0);
  for (int g = 0; g < G; ++g) {
#endif

    // current value for each gene
    arma::rowvec gamma_row  = gamma_init.row(g);
    arma::rowvec delta2_row = delta2_init.row(g);
    arma::rowvec eta_row    = eta_init.row(g);

    // save
    arma::mat gamma_save(B, num_iters, arma::fill::zeros);
    arma::mat delta2_save(B, num_iters, arma::fill::zeros);
    arma::mat eta_save(B, num_iters, arma::fill::zeros);

    // ---------- Gibbs+MH for each batch i ----------
    for (int i = 0; i < B; ++i) {

      int n_i = static_cast<int>(num_samples(i));
      const arma::mat &Zi   = Z_list[i];  // G × n_i
      const arma::mat &D_i  = D_list[i];  // n_i × n_i

      arma::vec tmpZ = Zi.row(g).t();     // n_i × 1

      double gamma_est  = gamma_row(i);
      double delta2_est = delta2_row(i);
      double eta_est    = eta_row(i);

      for (int it = 0; it < num_iters; ++it) {

        // ---- 1) Lambda(eta) and Cholesky ----
        arma::mat Lambda_eta = make_Lambda(D_i, eta_est);
        arma::mat L_Lambda   = arma::chol(Lambda_eta, "lower"); // Lambda = L L'

        // ---- 2) update gamma_ig ----
        if (i > 0) {
          arma::vec ones(n_i, arma::fill::ones);

          // Lambda^{-1} 1
          arma::vec y1 = arma::solve(arma::trimatl(L_Lambda), ones);
          arma::vec v1 = arma::solve(arma::trimatu(L_Lambda.t()), y1); // = Lambda^{-1} 1

          // Lambda^{-1} z
          arma::vec y2 = arma::solve(arma::trimatl(L_Lambda), tmpZ);
          arma::vec v2 = arma::solve(arma::trimatu(L_Lambda.t()), y2); // = Lambda^{-1} z

          // Σ = delta2 * Lambda => Sigma^{-1} = (1/delta2) * Lambda^{-1}
          double sum_invSigma = arma::sum(v1) / delta2_est;  // 1' Sigma^{-1} 1
          double oneT_Sinv_z  = arma::sum(v2) / delta2_est;  // 1' Sigma^{-1} z

          double tau2     = tau2_b(i - 1);
          double gammaBar = kappa_b(i - 1);

          double tmpDe   = sum_invSigma + 1.0 / tau2;
          double tmpMean = (oneT_Sinv_z + gammaBar / tau2) / tmpDe;
          double tmpVar  = 1.0 / tmpDe;

          std::normal_distribution<double> norm01(0.0, 1.0);
          double z = norm01(rng);
          gamma_est = tmpMean + std::sqrt(tmpVar) * z;
        }

        // ---- 3) update delta2_ig ----
        arma::vec z_centered = tmpZ - gamma_est;

        arma::vec y3 = arma::solve(arma::trimatl(L_Lambda), z_centered);
        arma::vec v3 = arma::solve(arma::trimatu(L_Lambda.t()), y3); // = Lambda^{-1}(z-gamma)
        double quad_Lambda = arma::dot(z_centered, v3);

        double lambda_post = lambda_delta_b(i) + n_i / 2.0;
        double theta_post  = theta_delta_b(i) + 0.5 * quad_Lambda;

        // 1 / delta2 ~ Gamma(shape=lambda_post, rate=theta_post)
        std::gamma_distribution<double> gamma_dist(lambda_post, 1.0 / theta_post);
        double y_gam = gamma_dist(rng);
        delta2_est = 1.0 / y_gam;

        // ---- 4) update eta_ig (MH, truncated normal proposal) ----
        double eta0     = eta_est;
        double eta_prop = rtruncnorm_0inf(eta0, 1.0, rng);

        // (a) current eta0: covariance log-lik
        arma::vec mu_vec(n_i, arma::fill::ones);
        mu_vec *= gamma_est;
        arma::vec z_minus_mu = tmpZ - mu_vec;

        double logLik_orig = log_mvn_from_Lambda_delta(z_minus_mu, L_Lambda, delta2_est);

        // (b) log-lik of eta_prop
        arma::mat Lambda_prop = make_Lambda(D_i, eta_prop);
        arma::mat L_Lambda_prop = arma::chol(Lambda_prop, "lower");
        double logLik_prop = log_mvn_from_Lambda_delta(z_minus_mu, L_Lambda_prop, delta2_est);

        // (c) prior: Inv-Gamma(lambda_eta_b[i], theta_eta_b[i])
        double logPrior_prop = log_dinvgamma(eta_prop, lambda_eta_b(i), theta_eta_b(i));
        double logPrior_orig = log_dinvgamma(eta0,    lambda_eta_b(i), theta_eta_b(i));

        // (d) proposal density
        double logQ_prop_given_orig = log_dtruncnorm_0inf(eta_prop, eta0,   1.0);
        double logQ_orig_given_prop = log_dtruncnorm_0inf(eta0,    eta_prop, 1.0);

        double logNu    = logLik_prop + logPrior_prop + logQ_orig_given_prop;
        double logDe    = logLik_orig + logPrior_orig + logQ_prop_given_orig;
        double logRatio = logNu - logDe;

        double u = unif01(rng);
        if (std::log(u) < logRatio) {
          eta_est = eta_prop;  // accept
        } else {
          eta_est = eta0;      // reject
        }

        // ---- save ----
        gamma_save(i, it)  = gamma_est;
        delta2_save(i, it) = delta2_est;
        eta_save(i, it)    = eta_est;
      } // end iter
    }   // end i (batch)

    // total cube：g-th slice/gene
    for (int i = 0; i < B; ++i) {
      for (int it = 0; it < num_iters; ++it) {
        gamma_post(g, i, it)  = gamma_save(i, it);
        delta2_post(g, i, it) = delta2_save(i, it);
        eta_post(g, i, it)    = eta_save(i, it);
      }
    }

  } // end for g
}   // end parallel block

    // ---- arma::cube -> 3D array in R ----
    Rcpp::NumericVector gamma_out = Rcpp::wrap(gamma_post);
    Rcpp::NumericVector delta2_out = Rcpp::wrap(delta2_post);
    Rcpp::NumericVector eta_out = Rcpp::wrap(eta_post);

    gamma_out.attr("dim")  = Rcpp::IntegerVector::create(G, B, num_iters);
    delta2_out.attr("dim") = Rcpp::IntegerVector::create(G, B, num_iters);
    eta_out.attr("dim")    = Rcpp::IntegerVector::create(G, B, num_iters);

    return Rcpp::List::create(
      Rcpp::Named("gamma_post")  = gamma_out,
      Rcpp::Named("delta2_post") = delta2_out,
      Rcpp::Named("eta_post")    = eta_out
    );
  }


// ----------------------------
// Robust median / quantile
// ----------------------------
static inline double median_cpp(const arma::vec& x) {
  if (x.n_elem == 0) return NA_REAL;
  arma::vec y = x;
  y = arma::sort(y);
  const arma::uword n = y.n_elem;
  if (n % 2 == 1) return y(n / 2);
  return 0.5 * (y(n / 2 - 1) + y(n / 2));
}

static inline double quantile_cpp(const arma::vec& x, double B) {
  if (x.n_elem == 0) return NA_REAL;
  arma::vec y = arma::sort(x);
  if (B <= 0.0) return y(0);
  if (B >= 1.0) return y(y.n_elem - 1);
  double idx = B * (y.n_elem - 1);
  arma::uword lo = (arma::uword)std::floor(idx);
  arma::uword hi = (arma::uword)std::ceil(idx);
  if (hi == lo) return y(lo);
  double w = idx - lo;
  return (1.0 - w) * y(lo) + w * y(hi);
}

// ----------------------------
// Precompute equal-width bins on distances
// ----------------------------
static inline std::vector<arma::uvec>
make_bins_equal_width(const arma::vec& dists_tri, int nbins, double eps) {
  std::vector<arma::uvec> bins;
  bins.reserve(nbins);

  double dmax = dists_tri.max();
  if (!std::isfinite(dmax) || dmax <= eps) {
    // degenerate: put everything into one bin
    bins.push_back(arma::regspace<arma::uvec>(0, dists_tri.n_elem - 1));
    return bins;
  }

  double width = dmax / nbins;
  if (width <= eps) width = dmax;

  for (int j = 0; j < nbins; ++j) {
    double a = j * width;
    double b = (j == nbins - 1) ? (dmax + eps) : ((j + 1) * width);
    arma::uvec idx = arma::find((dists_tri >= a) && (dists_tri < b));
    bins.push_back(idx);
  }
  return bins;
}

// ----------------------------
// x0 init from variogram cloud (geoR-style logic)
// delta2_init: median sv at large distances
// eta_init: h50 / (2 log 2) where variogram reaches 0.5*sill
// ----------------------------
static inline arma::vec
estimate_x0_from_cloud(const arma::vec& z,
                       const arma::vec& sv_tri,
                       const arma::vec& dists_tri,
                       const std::vector<arma::uvec>& bins,
                       double eps) {

  arma::vec x0(2);

  // 1) delta2 init (sill)
  // use top 20% distances => sv approx sill
  double d80 = quantile_cpp(dists_tri, 0.80);
  arma::uvec hi_idx = arma::find(dists_tri >= d80);
  double delta2_init = NA_REAL;
  if (hi_idx.n_elem >= 10) {
    delta2_init = median_cpp(sv_tri.elem(hi_idx));
  } else {
    // fallback: use variance of z
    delta2_init = arma::var(z);
  }

  if (!std::isfinite(delta2_init) || delta2_init <= eps) {
    delta2_init = std::max(arma::var(z), 1e-6);
  }

  // 2) eta init via "half-sill distance"
  double target = 0.5 * delta2_init;

  // compute binned empirical variogram (median within each bin)
  std::vector<double> bin_dmid;
  std::vector<double> bin_sv;
  bin_dmid.reserve(bins.size());
  bin_sv.reserve(bins.size());

  double dmax = dists_tri.max();
  double width = (std::isfinite(dmax) && dmax > eps) ? (dmax / (double)bins.size()) : 1.0;

  for (size_t j = 0; j < bins.size(); ++j) {
    const arma::uvec& idx = bins[j];
    if (idx.n_elem < 10) continue; // too few pairs => skip
    double sv_med = median_cpp(sv_tri.elem(idx));
    // mid distance for this equal-width bin
    double d_mid = (j + 0.5) * width;

    if (std::isfinite(sv_med) && std::isfinite(d_mid)) {
      bin_sv.push_back(sv_med);
      bin_dmid.push_back(d_mid);
    }
  }

  double eta_init = NA_REAL;

  if (bin_sv.size() >= 2) {
    // find first crossing of target
    for (size_t j = 0; j < bin_sv.size(); ++j) {
      if (bin_sv[j] >= target) {
        double h50 = bin_dmid[j];
        eta_init = h50 / (2.0 * std::log(2.0));
        break;
      }
    }
  }

  // fallback if never crossed
  if (!std::isfinite(eta_init) || eta_init <= eps) {
    double d95 = quantile_cpp(dists_tri, 0.95);
    if (!std::isfinite(d95) || d95 <= eps) d95 = arma::mean(dists_tri);
    if (!std::isfinite(d95) || d95 <= eps) d95 = 1.0;
    eta_init = 0.25 * d95; // loose, stable default
  }

  x0(0) = std::max(delta2_init, eps);
  x0(1) = std::max(eta_init,   eps);
  return x0;
}


// [[Rcpp::export]]
Rcpp::List semivar_optim(int B,
                         int G,
                         arma::vec num_samples,
                         Rcpp::List Z_mat,          // len B, each: NumericMatrix (G x n_i)
                         Rcpp::List dists_tri_save, // len B, each: vector length n_i*(n_i-1)/2
                         Rcpp::List dists_save,     // len B, each: matrix n_i x n_i
                         int maxit = 200,
                         double eps = 1e-8,
                         int nbins = 15) {

  // R functions
  Rcpp::Environment stats("package:stats");
  Rcpp::Function optim = stats["optim"];

  arma::mat gamma_ig_hat(G, B, arma::fill::zeros);
  arma::mat delta2_ig_hat(G, B, arma::fill::zeros);
  arma::mat eta_ig_hat(G, B, arma::fill::zeros);

  // lower bounds for (delta2, eta)
  arma::vec lower_vec(2, arma::fill::ones);
  lower_vec *= eps;

  arma::vec upper_vec(2);
  upper_vec(0) = R_PosInf;   // delta2 upper
  upper_vec(1) = R_PosInf;   // eta upper

  for (int i = 0; i < B; ++i) {
    // distances (fixed per batch)
    arma::vec dists_tri = as<arma::vec>(dists_tri_save[i]);
    arma::mat dists     = as<arma::mat>(dists_save[i]);

    // Precompute bins once per batch (geoR-like)
    std::vector<arma::uvec> bins = make_bins_equal_width(dists_tri, nbins, eps);

    // Z matrix for this batch: G x n_i
    Rcpp::NumericMatrix tmpZ = Z_mat[i];
    int n_i = static_cast<int>(num_samples(i));

    // mean across genes for each cell (your earlier block used this)
    arma::rowvec col_mean = colMeans_rcpp(tmpZ);

    for (int g = 0; g < G; ++g) {

      arma::vec tmpZ_g = as<arma::vec>(wrap(tmpZ(g, _)));

      // gamma: sample mean for batches > 1 (match your convention)
      if (i > 0) {
        gamma_ig_hat(g, i) = arma::mean(tmpZ_g);
      } else {
        gamma_ig_hat(g, i) = 0.0; // baseline batch
      }

      // center for semivariance cloud (stable)
      arma::vec z = tmpZ_g - arma::mean(tmpZ_g);

      // semivariogram cloud vector (same order as dists_tri_save)
      arma::vec sv_tri = semivar_cloud_from_z(z);

      // ---- NEW: simple and general x0 init (geoR-style) ----
      arma::vec x0 = estimate_x0_from_cloud(z, sv_tri, dists_tri, bins, eps);
      // -----------------------------------------------

      // Call R's optim (L-BFGS-B) with our C++ objective
      Rcpp::List opt_res = optim(
        Rcpp::_["par"]    = x0,
        Rcpp::_["fn"]     = Rcpp::InternalFunction(&obj_cloud_wls_equal_wrap),
        Rcpp::_["method"] = "L-BFGS-B",
        Rcpp::_["lower"]  = lower_vec,
        Rcpp::_["upper"]  = upper_vec,
        Rcpp::_["control"]= Rcpp::List::create(
          Rcpp::Named("maxit") = maxit
        ),
        // extra args passed to fn(...)
        Rcpp::_["svSEXP"]  = sv_tri,
        Rcpp::_["dSEXP"]   = dists_tri,
        Rcpp::_["epsSEXP"] = eps
      );

      arma::vec par_hat = Rcpp::as<arma::vec>(opt_res["par"]);

      delta2_ig_hat(g, i) = par_hat(0);
      eta_ig_hat(g, i)    = par_hat(1);
    }
  }

  return Rcpp::List::create(
    Rcpp::Named("gamma_ig_hat")  = gamma_ig_hat,
    Rcpp::Named("delta2_ig_hat") = delta2_ig_hat,
    Rcpp::Named("eta_ig_hat")    = eta_ig_hat
  );
}


// [[Rcpp::export]]
arma::mat adjust_batch_cpp(
    const arma::mat& Z_b,           // G x n_i
    const arma::mat& dist_i,        // n_i x n_i
    const arma::vec& gamma_est,     // G
    const arma::vec& delta2_est,    // G
    const arma::vec& eta_est,       // G
    const arma::vec& sigma2_g_est,  // G
    const arma::vec& alpha_g,       // G
    const arma::mat& beta_matrix,   // G x K
    const arma::uvec& labels_i,     // n_i
    int n_threads = 1) {

  int G = Z_b.n_rows;
  int n_i = Z_b.n_cols;
  arma::mat correct_data_i(G, n_i);

  // use omp to accelerate
#pragma omp parallel for num_threads(n_threads) schedule(static)
  for (int g = 0; g < G; ++g) {
    double g_gamma  = gamma_est[g];
    double g_delta2 = delta2_est[g];
    double g_eta    = eta_est[g];
    double g_sigma2 = sigma2_g_est[g];
    double g_alpha  = alpha_g[g];
    double sqrt_s2  = std::sqrt(g_sigma2);

    // 1. Build Lambda
    // Lambda = exp( -dist / (2 * eta) )
    arma::mat Lambda_mat = arma::exp(-dist_i / (2.0 * g_eta));
    // arma::mat Lambda_mat = Lambda_func_rcpp(dist_i, g_eta);

    // 2. Cholesky decomposition: Sigma = delta2 * Lambda
    arma::mat L_mat;
    arma::mat Sigma = g_delta2 * Lambda_mat;

    // Safety check: if the matrix is not positive definite, add a small perturbation (nugget).
    if (!arma::chol(L_mat, Sigma)) {
      Sigma.diag() += 1e-9;
      arma::chol(L_mat, Sigma);
    }
    // Note: Armadillo's chol() returns an upper-triangular factor by default (L.t() * L = Sigma).
    // R's chol() also returns an upper-triangular factor.

    // 3. Whitening
    // Goal: solve(L_mat.t(), (Z - gamma))
    arma::vec z_centered = (Z_b.row(g) - g_gamma).t();

    // Solve L.t * x = z_centered -> x is the whitened vector.
    // Use trimatl() to tell the compiler that L.t() is lower-triangular, which speeds up the solve.
    arma::vec whitened = arma::solve(arma::trimatl(L_mat.t()), z_centered);

    // 4. Restore the original data scale and add the biological effect back.
    // correct = sqrt(sigma2) * whitened + alpha + beta[label]
    for (int j = 0; j < n_i; ++j) {
      unsigned int lab_idx = labels_i[j] - 1; // 1-based to 0-based
      correct_data_i(g, j) = sqrt_s2 * whitened(j) + g_alpha + beta_matrix(g, lab_idx);
    }
  }

  return correct_data_i;
}
