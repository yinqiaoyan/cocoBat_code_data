#' cocoBat main function
#'
#' @description
#' This function implements:
#' 1. Ordinary least squares (OLS) to construct standardized residuals `Z_mat`;
#' 2. Empirical Bayes estimation of hyperparameters;
#' 3. MCMC sampling for gene- and batch-specific parameters using a
#'    Metropolis–Hastings-within-Gibbs scheme in parallel over genes.
#'
#' @param Y_mat List of length \code{B}; each element is a data matrix
#'   \code{G x num_samples[b]} containing gene expression values.
#' @param true_labels_save List of length \code{B}; each element is an integer vector
#'   of length \code{num_samples[b]} giving the true cell-type label (1..K) for each cell.
#' @param dists_tri_save List of length \code{B} passed directly to \code{semivar_optim}
#'   (triangular distance matrices).
#' @param dists_save List of length \code{B} passed directly to \code{semivar_optim}
#'   (distance matrices).
#' @param random_seed Random seed for reproducibility. Default is 45.
#' @param maxit Integer, maximum number of iterations for moment-matching. Default is 10.
#' @param num_iters Integer, number of MCMC iterations. Default is 100.
#' @param n_threads Integer, total number of threads on the machine; the function will use
#'   \code{n_threads} worker processes. Default is 4.
#' @param verbose Logical, whether to print progress messages and timing information. Default is TRUE.
#'
#' @return A list with components:
#' \itemize{
#'   \item \code{param_est_mat}: OLS estimates, \code{G x [1 + (K - 1) + (B - 1)]}.
#'   \item \code{sigma2_g_est}: Gene-specific residual variances, length \code{G}.
#'   \item \code{Z_mat}: List of length \code{B}, each containing a \code{G x num_samples[b]}
#'         matrix of the standardized data.
#'   \item \code{gamma_post}, \code{delta2_post}, \code{eta_post}:
#'         Arrays of dimension \code{G x B x num_iters} with MCMC samples.
#'   \item \code{gamma_est}, \code{delta2_est}, \code{eta_est}:
#'         Posterior means from the MCMC samples, each a \code{G x B} matrix.
#'   \item \code{corrected_data}: The corrected data obtained by cocoBat.
#'   \item \code{timing}: Named list with timing information for each step.
#' }
#'
#' @export
run_eb_mcmc <- function(Y_mat,
                        true_labels_save,
                        dists_tri_save,
                        dists_save,
                        random_seed = 45,
                        maxit       = 10,
                        num_iters   = 100,
                        n_threads   = 4,
                        verbose     = TRUE) {

  # Integer larger than 1, number of batches.
  B = length(Y_mat)
  # Integer, number of genes.
  G = nrow(Y_mat[[1]])
  # Integer, number of cell types.
  K = length(unique(unlist(true_labels_save)))
  # Integer vector of length B, number of cells in each batch.
  num_samples = sapply(true_labels_save, length)

  ## ---------------------------------------------------------------------------
  ## Step 1. Standardization (using OLS)
  ## ---------------------------------------------------------------------------
  if (verbose) {
    message("=== Step 1. Standardization ===")
  }

  # Build design matrix for cell-type indicators (excluding baseline type 1)
  tmp_X_type = vector("list", B)
  for (b in 1:B) {
    tmpMat = matrix(0, nrow = num_samples[b], ncol = K)
    for (j in 1:num_samples[b]) {
      tmpMat[j, true_labels_save[[b]][j]] = 1
    }
    tmp_X_type[[b]] = tmpMat[, -1]
  }
  X_type = Reduce(rbind, tmp_X_type)

  # Build batch indicator matrix (excluding first batch as baseline)
  N = sum(num_samples)
  tmp_IsGammaMat = vector("list", B)
  tmp_IsGammaMat[[1]] = matrix(0, nrow = num_samples[1], ncol = B - 1)

  for (b in 2:B) {
    tmp_IsGammaMat[[b]] = matrix(0, nrow = num_samples[b], ncol = B - 1)
    tmp_IsGammaMat[[b]][, b - 1] = 1
  }

  IsGammaMat = Reduce(rbind, tmp_IsGammaMat)
  X = cbind(1, X_type, IsGammaMat)
  # dim: N * [1 + (K - 1) + (B - 1)]

  param_est_mat = matrix(NA, nrow = G, ncol = 1 + (K - 1) + (B - 1))
  # dim: G * [1 + (K - 1) + (B - 1)]
  sigma2_g_est = numeric(G)

  Z_mat = vector("list", B)
  for (b in 1:B) {
    Z_mat[[b]] = matrix(NA, nrow = G, ncol = num_samples[b])
  }

  ni_csum = cumsum(c(0, num_samples))

  ss1 = Sys.time()
  for (g in 1:G) {
    Y = unlist(Map(function(x){x[g, ]}, Y_mat))
    tmpParam = solve(t(X) %*% X) %*% t(X) %*% as.matrix(Y)
    param_est_mat[g, ] = tmpParam
    sigma2_g_est[g] = sum((Y - X %*% tmpParam)^2) / N

    X_new1 = X[, 1:K]
    X_new2 = X[, (K+1):ncol(X)]
    X_new2[X_new2 == 1] = 1 - sqrt(sigma2_g_est[g])
    X_new = cbind(X_new1, X_new2)

    Z = (Y - X_new %*% tmpParam) / sqrt(sigma2_g_est[g])
    for (b in 1:B) {
      Z_mat[[b]][g, ] = Z[ (ni_csum[b] + 1):ni_csum[b + 1] ]
    }
  }
  ee1 = Sys.time()


  ## ---------------------------------------------------------------------------
  ## Step 2. Moment matching for hyperparameters
  ## ---------------------------------------------------------------------------
  if (verbose) {
    message("=== Step 2. Moment matching ===")
  }
  ss2 = Sys.time()

  res <- semivar_optim(
    B = B, G = G,
    num_samples = num_samples,
    Z_mat = Z_mat,
    dists_tri_save = dists_tri_save,
    dists_save = dists_save,
    maxit = maxit,
    eps = 1e-8
  )


  gamma_bg_hat  <- res$gamma_ig_hat
  delta2_bg_hat <- res$delta2_ig_hat
  eta_bg_hat    <- res$eta_ig_hat


  # Hyperparameters across genes
  kappa_b        <- numeric(B - 1L)
  tau2_b         <- numeric(B - 1L)
  lambda_delta_b <- numeric(B)
  theta_delta_b  <- numeric(B)
  lambda_eta_b   <- numeric(B)
  theta_eta_b    <- numeric(B)

  for (b in seq_len(B)) {
    # Hyperparameters for gamma_bg (only for b > 1)
    if (b > 1L) {
      kappa_b[b - 1] <- mean(gamma_bg_hat[, b])
      tau2_b[b - 1]  <- var(gamma_bg_hat[, b])
    }

    # Hyperparameters for delta2_bg (inverse-gamma)
    U_delta_b <- mean(delta2_bg_hat[, b])
    V_delta_b <- var(delta2_bg_hat[, b])
    lambda_delta_b[b] <- U_delta_b^2 / V_delta_b + 2
    theta_delta_b[b]  <- U_delta_b^3 / V_delta_b + U_delta_b

    # Hyperparameters for eta_bg (inverse-gamma)
    U_eta_b <- mean(eta_bg_hat[, b])
    V_eta_b <- var(eta_bg_hat[, b])
    lambda_eta_b[b] <- U_eta_b^2 / V_eta_b + 2
    theta_eta_b[b]  <- U_eta_b^3 / V_eta_b + U_eta_b
  }

  ee2 = Sys.time()


  ## ---------------------------------------------------------------------------
  ## Step 3. Initialization and MCMC
  ## ---------------------------------------------------------------------------
  if (verbose) {
    message("=== Step 3. Initialization and MCMC ===")
  }

  set.seed(random_seed)

  # Allocate arrays for MCMC samples
  gamma_post = array(NA, dim = c(G, B, num_iters))
  delta2_post = array(NA, dim = c(G, B, num_iters))
  eta_post = array(NA, dim = c(G, B, num_iters))

  # Initial values for gamma, delta2, eta
  gamma_est = matrix(0, nrow = G, ncol = B)
  delta2_est = matrix(0, nrow = G, ncol = B)
  eta_est = matrix(0, nrow = G, ncol = B)

  for (b in 1:B) {
    if (b > 1) {
      gamma_est[, b] = rnorm(G, mean = kappa_b[b - 1], sd = sqrt(tau2_b[b - 1]))
    }
    delta2_est[, b] = MCMCpack::rinvgamma(G, shape = lambda_delta_b[b], scale = theta_delta_b[b])
    eta_est[, b] = MCMCpack::rinvgamma(G, shape = lambda_eta_b[b], scale = theta_eta_b[b])
  }

  ss3 <- Sys.time()

  res_cpp <- mcmc_all_genes_cpp(
    G             = G,
    B             = B,
    num_iters     = num_iters,
    Z_mat         = Z_mat,
    dists_list    = dists_save,
    num_samples   = num_samples,
    gamma_init    = gamma_est,
    delta2_init   = delta2_est,
    eta_init      = eta_est,
    kappa_b   = kappa_b,
    tau2_b    = tau2_b,
    lambda_delta_b  = lambda_delta_b,
    theta_delta_b   = theta_delta_b,
    lambda_eta_b       = lambda_eta_b,
    theta_eta_b       = theta_eta_b,
    base_seed     = random_seed,
    n_threads     = n_threads
  )

  gamma_post  <- res_cpp$gamma_post  # G × B × num_iters
  delta2_post <- res_cpp$delta2_post
  eta_post    <- res_cpp$eta_post

  ee3 <- Sys.time()

  post_samples = ceiling(num_iters / 2 + 1):num_iters

  gamma_est_post  <- apply(gamma_post[, , post_samples], c(1, 2), mean)
  delta2_est_post <- apply(delta2_post[, , post_samples], c(1, 2), mean)
  eta_est_post    <- apply(eta_post[, , post_samples], c(1, 2), mean)


  ## ---------------------------------------------------------------------------
  ## Step 4. Adjust the raw data
  ## ---------------------------------------------------------------------------
  if (verbose) message("=== Step 4. Adjusting the Data ===")
  ss4 <- Sys.time()

  alpha_g_vec <- param_est_mat[, 1]
  beta_mat_full <- matrix(0, nrow = G, ncol = K)
  if (K > 1) {
    beta_mat_full[, 2:K] <- param_est_mat[, 2:K]
  }

  n_threads_to_use <- max(n_threads, parallel::detectCores() - 2)

  correct_data <- vector("list", B)

  for (b in seq_len(B)) {
    if (verbose) message(sprintf("  Adjusting Batch %d/%d...", b, B))

    correct_data[[b]] <- adjust_batch_cpp(
      Z_b           = as.matrix(Z_mat[[b]]),
      dist_i        = as.matrix(dists_save[[b]]),
      gamma_est     = gamma_est_post[, b],
      delta2_est    = delta2_est_post[, b],
      eta_est       = eta_est_post[, b],
      sigma2_g_est  = as.numeric(sigma2_g_est),
      alpha_g       = as.numeric(alpha_g_vec),
      beta_matrix   = as.matrix(beta_mat_full),
      labels_i      = as.integer(true_labels_save[[b]]),
      n_threads     = n_threads_to_use
    )
  }

  ee4 <- Sys.time()


  ## ---------------------------------------------------------------------------
  ## Timing output
  ## ---------------------------------------------------------------------------
  timing <- list(
    std    = ee1 - ss1,
    mm     = ee2 - ss2,
    eb     = ee3 - ss3,
    adjust = ee4 - ss4,
    total  = ee4 - ss1
  )

  if (verbose) {
    message("Time - Step 1 (STD):   ", signif(as.numeric(timing$std,    units = "mins"), 3), " min")
    message("Time - Step 2 (MM):    ", signif(as.numeric(timing$mm,     units = "mins"), 3), " min")
    message("Time - Step 3 (EB):    ", signif(as.numeric(timing$eb,     units = "mins"), 3), " min")
    message("Time - Step 4 (Adjust):", signif(as.numeric(timing$adjust, units = "mins"), 3), " min")
    message("Time - Total          :", signif(as.numeric(timing$total , units = "mins"), 3), " min")
  }

  list(
    param_est_mat  = param_est_mat,
    sigma2_g_est   = sigma2_g_est,
    Z_mat          = Z_mat,
    gamma_post     = gamma_post,
    delta2_post    = delta2_post,
    eta_post       = eta_post,
    gamma_est      = gamma_est_post,
    delta2_est     = delta2_est_post,
    eta_est        = eta_est_post,
    corrected_data = correct_data,
    timing         = timing
  )
}
